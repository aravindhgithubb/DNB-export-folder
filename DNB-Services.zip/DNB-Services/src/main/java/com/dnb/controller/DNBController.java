package com.dnb.controller;

import java.awt.FileDialog;
import java.awt.Frame;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JFileChooser;
import javax.ws.rs.FormParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.dnb.model.Accomodation;
import com.dnb.model.Person;
import com.dnb.serviceimpl.CustomerDetailsImpl;
import com.dnb.util.MediaTypeUtils;

@Controller
public class DNBController {
	private static final String DIRECTORY = "C:/PDF";
	private static final String DEFAULT_FILE_NAME = "java-tutorial.pdf";

	@Autowired
	private CustomerDetailsImpl customerDetailsImpl;
	@Autowired
	private ServletContext servletContext;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView loadLogin(String username, String password) {

		return new ModelAndView("login");

	}
	
@RequestMapping(value = "/search", method = RequestMethod.GET)
@ModelAttribute("username")
	public ModelAndView getCustomerDetail(HttpServletResponse response,ModelMap mod,String username, String password) {
	 final String token =username;
     Cookie cookie = new Cookie("token", token);
	    response.addCookie(cookie);
		if (username.equals("john") && password.equals("john")) {
			mod.addAttribute("loginName", username);
			// Cookie firstName = new Cookie("loginName",username);
			// firstName.setMaxAge(60*60*24);  
			 //response.addCookie( firstName );
			return new ModelAndView("search");
			
		} else {
			return new ModelAndView("failure");
		}
	}
	
	/*@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView getCustomerDetail(@CookieValue(value = "username",
            defaultValue = "username")String username, String password,ModelMap mod) {
		System.out.println(username);
		if (username.equals("john") && password.equals("john")) {
			mod.addAttribute("loginName", username);
			mod.addAttribute("cookieValue", username);
			// Cookie firstName = new Cookie("loginName",username);
			// firstName.setMaxAge(60*60*24);  
			 //response.addCookie( firstName );
			return new ModelAndView("search");
			
		} else {
			return new ModelAndView("failure");
		}
	}*/

	@RequestMapping(value = "/search/{searchKey}", method = RequestMethod.GET)
	public @ResponseBody List<Person> getCustomerDetails(@PathVariable(value = "searchKey") String searchKey)
			throws Exception {
		List<Person> cusPo = new ArrayList<Person>();
		cusPo = customerDetailsImpl.getCustomerDetailsKeySearchFirst(searchKey);
		return cusPo;
	}

	@RequestMapping(value = "/searchlast/{searchKey}", method = RequestMethod.GET)
	public @ResponseBody List<Person> getCustomerDetailsLast(@PathVariable(value = "searchKey") String searchKey)
			throws Exception {
		List<Person> cusPo = new ArrayList<Person>();
		cusPo = customerDetailsImpl.getCustomerDetailsKeySearchLast(searchKey);
		return cusPo;
	}

	@RequestMapping(value = "/searchmob/{searchKey}", method = RequestMethod.GET)
	public @ResponseBody List<Person> getCustomerDetailsMob(@PathVariable(value = "searchKey") String searchKey)
			throws Exception {
		List<Person> cusPo = new ArrayList<Person>();
		cusPo = customerDetailsImpl.getCustomerDetailsKeySearchMob(searchKey);
		return cusPo;
	}

	@RequestMapping(value = "/searchemail/{searchKey}", method = RequestMethod.GET)
	public @ResponseBody List<Person> getCustomerDetailsEmail(@PathVariable(value = "searchKey") String searchKey)
			throws Exception {
		List<Person> cusPo = new ArrayList<Person>();
		cusPo = customerDetailsImpl.getCustomerDetailsKeyMail(searchKey);
		return cusPo;
	}

	@RequestMapping(value = "/searchadd/{searchKey}", method = RequestMethod.GET)
	public @ResponseBody List<Person> getCustomerDetailsAdd(@PathVariable(value = "searchKey") String searchKey)
			throws Exception {
		List<Person> cusPo = new ArrayList<Person>();
		cusPo = customerDetailsImpl.getCustomerDetailsKeyAdd(searchKey);
		return cusPo;
	}

	@RequestMapping(value = "/newSearch", method = RequestMethod.GET)
	public ModelAndView getCustomerDetailsSearch(HttpServletResponse response,ModelMap mod,HttpSession session) {
		// CustomerDetails cusPo = new CustomerDetails();
		// mod.addAttribute(cusPo);
		//response.addCookie(new Cookie("username", "username"));
		session.invalidate();
		return new ModelAndView("search");
	}

	@RequestMapping("/logout.do")
	public ModelAndView logout(HttpSession session) {
		session.invalidate();
		return new ModelAndView("/login");// if you have two differenet web pages for login and logout else you can
											// redirect to login.jsp
	}

	@RequestMapping(value = "/newResult", method = RequestMethod.GET)
	public ModelAndView getCustomerDetails(@ModelAttribute("cusPo") Person cusPo, @FormParam("name") String name,
			@FormParam("phoneNo") String phoneNo, @FormParam("lname") String lname,
			@FormParam("address") String address, @FormParam("email") String email, Model model, ModelMap m) {
		System.out.println("inside customer details");

		List<Person> cus;
		try {
			cus = customerDetailsImpl.getCustomerDetails(name, phoneNo, lname, address, email);
			if (cus != null) {
				model.addAttribute("firstname", cus.iterator().next().getFirstname());
				model.addAttribute("lastname", cus.iterator().next().getLastname());
				model.addAttribute("mobilephone", cus.iterator().next().getPhone_mobile());
				model.addAttribute("phonehome", cus.iterator().next().getPhone_home());
				model.addAttribute("email", cus.iterator().next().getEmail());
				model.addAttribute("streetaddress", cus.iterator().next().getStreetaddress());
				model.addAttribute("postalcode", cus.iterator().next().getPostalcode());
				model.addAttribute("economicaladvice", cus.iterator().next().getEconomicaladvice());
				model.addAttribute("Town", cus.iterator().next().getTown());
				model.addAttribute("birthday", cus.iterator().next().getBirthday());
				model.addAttribute("note", cus.iterator().next().getNote());
				model.addAttribute("emprof", cus.iterator().next().getEmprofid());
				model.addAttribute("hasowner", cus.iterator().next().getHasownership());
				model.addAttribute("latestbiding", cus.iterator().next().getLatestbidding());
				model.addAttribute("isbuyer", cus.iterator().next().getIsbuyer());

				model.addAttribute("postalcode",
						cus.iterator().next().getOwns().iterator().next().getAccomodation().getPostalcode());
				model.addAttribute("streetaddress",
						cus.iterator().next().getOwns().iterator().next().getAccomodation().getStreetaddress());
				model.addAttribute("areal",
						cus.iterator().next().getOwns().listIterator().next().getAccomodation().getAreal());
				model.addAttribute("rooms",
						cus.iterator().next().getOwns().listIterator().next().getAccomodation().getRooms());
				model.addAttribute("currency",
						cus.iterator().next().getOwns().listIterator().next().getAccomodation().getCurrency());
				model.addAttribute("accomodation",
						cus.iterator().next().getOwns().listIterator().next().getAccomodation().getPostalcode());
				model.addAttribute("agentid",
						cus.iterator().next().getOwns().listIterator().next().getAccomodation().getAgentid());
				model.addAttribute("officeid",
						cus.iterator().next().getOwns().listIterator().next().getAccomodation().getOfficeid());
				model.addAttribute("created",
						cus.iterator().next().getOwns().listIterator().next().getAccomodation().getCreated());
				model.addAttribute("acctype",
						cus.iterator().next().getOwns().listIterator().next().getAccomodation().getAccomodationtype());
				model.addAttribute("consyear",
						cus.iterator().next().getOwns().listIterator().next().getAccomodation().getConstructionyear());
				model.addAttribute("lastupdated",
						cus.iterator().next().getOwns().listIterator().next().getAccomodation().getLastupdated());
				model.addAttribute("town",
						cus.iterator().next().getOwns().listIterator().next().getAccomodation().getTown());
				model.addAttribute("apartnumner",
						cus.iterator().next().getOwns().listIterator().next().getAccomodation().getApartmentnumber());

				model.addAttribute("ownstreet", cus.iterator().next().getOwns().iterator().next().getSource());
				model.addAttribute("statuschanged",
						cus.iterator().next().getOwns().iterator().next().getStatuschanged());
				model.addAttribute("lasst", cus.iterator().next().getOwns().iterator().next().getLastupdated());
				model.addAttribute("owned", cus.iterator().next().getOwns().iterator().next().getOwned());

				model.addAttribute("idcrm", cus.iterator().next().getBankCrmLead().iterator().next().getId());
				// model.addAttribute("personid",
				// cus.iterator().next().getBankCrmLead().iterator().next().getPerson());
				model.addAttribute("agentid", cus.iterator().next().getBankCrmLead().iterator().next().getAgentid());
				model.addAttribute("createdd", cus.iterator().next().getBankCrmLead().iterator().next().getCreated());

				// model.addAttribute("idint",
				// cus.iterator().next().getInterests().iterator().next().getAccomodation());
				// model.addAttribute("peronint",
				// cus.iterator().next().getInterests().iterator().next().);
				model.addAttribute("createint", cus.iterator().next().getInterests().iterator().next().getCreated());
				model.addAttribute("statusinter",
						cus.iterator().next().getInterests().iterator().next().getStatuschanged());
				model.addAttribute("ratingint", cus.iterator().next().getInterests().iterator().next().getRating());
				model.addAttribute("noteint", cus.iterator().next().getInterests().iterator().next().getNote());

				/*
				 * for (Accomodation tmp : cus.i { model.addAttribute("Visit",
				 * tmp.getStarttime()); model.addAttribute("visitid", tmp.getPersonid());
				 * model.addAttribute("id", tmp.getCustDetails().getId()); }
				 */
				// System.out.println("++++++" +
				// cus.iterator().next().getConer().iterator().next().getCowner());
				// model.addAttribute("coner",
				// cus.iterator().next().getConer().iterator().next().getCowner());

				ModelAndView m1 = new ModelAndView();
				m.addAttribute("model", model);
				m1.setViewName("newResult");
				m1.addObject("model", model);
				return m1;
			}

		}

		catch (Exception e) {
			System.out.println("Exception" + e);
		}
		return new ModelAndView("newResult");
	}

	@ModelAttribute
	public void addAttributes(Model model) {
		model.addAttribute("msg", "Welcome to the Netherlands!");
	}

@RequestMapping(value = "/cusDownLoadExcel/{temp}", method = RequestMethod.GET)
public ModelAndView getCustomerDetailsDownloadExcel(@PathVariable(value = "temp") String model,HttpServletResponse response, @RequestParam(defaultValue = DEFAULT_FILE_NAME) String fileName) throws IOException {
	Model m;
	List<Person> custDet= null;
	 String fullName= model;
	    String last=fullName.split(" ")[fullName.split(" ").length-1];
	    String first = fullName.substring(0, fullName.length() - last.length());
	System.out.println("++++++++"+model);
	//System.out.println("++++++++"+model);
	 //List<Person> usersGateways = customerDetailsImpl.getCustomerDetails();
	ModelAndView m1 = new ModelAndView();
			try {
				custDet = customerDetailsImpl.exportToExcel(first,last);
				if (custDet != null) {
					//Person details
					String firstName= custDet.iterator().next().getFirstname();
					String lastName=custDet.iterator().next().getLastname();
					String mobile=custDet.iterator().next().getPhone_mobile();
					String phonehome=custDet.iterator().next().getPhone_home();
					String email= custDet.iterator().next().getEmail();
					String streetaddress= custDet.iterator().next().getStreetaddress();
					String postcode= custDet.iterator().next().getPostalcode();
					String economical= custDet.iterator().next().getEconomicaladvice();
					String town= custDet.iterator().next().getTown();
					String birthday= custDet.iterator().next().getBirthday();
					String note=custDet.iterator().next().getNote();
				    String emprof= custDet.iterator().next().getEmprofid();
					String ownership= custDet.iterator().next().getHasownership();
					String latestbiding= custDet.iterator().next().getLatestbidding();
					String buyer= custDet.iterator().next().getIsbuyer();
					
					//Accomodation details
					String postacco=custDet.iterator().next().getOwns().iterator().next().getAccomodation().getPostalcode();
					String streetacco=custDet.iterator().next().getOwns().iterator().next().getAccomodation().getStreetaddress();
					String areal=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getAreal();
					String price=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getPrice();
					String rooms=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getRooms();
					String currency=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getCurrency();
					String agentid=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getAgentid();
					String officeid=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getOfficeid();
					String created=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getCreated();
					String accomodtype=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getAccomodationtype();
					String consyear=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getConstructionyear();
					String lastupdated=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getLastupdated();
					String townacco=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getTown();
			        String apartment=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getApartmentnumber();
					
			        //Owns deatisl
			        String ownstreet=custDet.iterator().next().getOwns().iterator().next().getSource();
					String statuscahnge= custDet.iterator().next().getOwns().iterator().next().getStatuschanged();
					String lastupdatedowns= custDet.iterator().next().getOwns().iterator().next().getLastupdated();
					String owned=custDet.iterator().next().getOwns().iterator().next().getOwned();
					
					//Bankcrm
					Integer id=custDet.iterator().next().getBankCrmLead().iterator().next().getId();
					String bankcrmid = Integer.toString(id);
					//model.addAttribute("personid", cus.iterator().next().getBankCrmLead().iterator().next().getPerson());
					String agentidbank=custDet.iterator().next().getBankCrmLead().iterator().next().getAgentid();
					String createdbank=custDet.iterator().next().getBankCrmLead().iterator().next().getCreated();
					
					
					//Interests
				//	model.addAttribute("idint", cus.iterator().next().getInterests().iterator().next().getAccomodation());
				//	model.addAttribute("peronint", cus.iterator().next().getInterests().iterator().next().);
					String createInt= custDet.iterator().next().getInterests().iterator().next().getCreated();
					String statuscahngedInter= custDet.iterator().next().getInterests().iterator().next().getStatuschanged();
					String rating= custDet.iterator().next().getInterests().iterator().next().getRating();
				String noteint= custDet.iterator().next().getInterests().iterator().next().getNote();
				
				String home = System.getProperty("user.home");
				File file = new File(home+"/Downloads/"+firstName+" "+lastName+".xlsx");
				
			/*	FileDialog fc; 
				 fc = new FileDialog(new Frame(),"Open file", FileDialog.LOAD);
				  fc.setDirectory(".");
			        fc.setVisible(true);
			        String path=fc.getDirectory (  )  + fc.getFile (  ) ; 
			        System.out.println(path);
				JFileChooser customer = new JFileChooser();
				customer.setCurrentDirectory(new java.io.File("."));
				customer.setDialogTitle("CustomerTitle");
				customer.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				customer.setAcceptAllFileFilterUsed(false);
				
				if(customer.showOpenDialog(null)==JFileChooser.APPROVE_OPTION)
				{
					   System.out.println("getCurrentDirectory(): " + customer.getCurrentDirectory());
					      System.out.println("getSelectedFile() : " + customer.getSelectedFile());
					    } else {
					      System.out.println("No Selection ");
					    }
				//String excelRootpath = "C:\\dnbexcel\\dnb.xlsx";*/
				FileOutputStream fileOutput = new FileOutputStream(file);
				// create xlsx workbook
				XSSFWorkbook workbook = new XSSFWorkbook();
				// create new worksheet
				XSSFSheet sheet = workbook.createSheet("Customer Details");
				XSSFSheet sheet1 = workbook.createSheet("Accomodation");
				XSSFSheet sheet2 = workbook.createSheet("Owns");
				XSSFSheet sheet3 = workbook.createSheet("Bank CRMLead");
				XSSFSheet sheet4 = workbook.createSheet("Interests");
				
				Object[][] dnbCustomers = { { "FirstName", firstName }, { "LastName", lastName }, { "Mobile", mobile},  { "Home_Phone", phonehome }, { "Email", email }, { "Street_Address", streetaddress },
						 { "Postal_code", postcode }, { "Economical", economical }, { "Town", town },{ "Birthday", birthday },{ "Note", note },{ "Town", town },{ "EmpProf", emprof },
						 { "Ownership", ownership },{ "latest_Biding", latestbiding },{ "Buyer", buyer }};
				
				Object[][] Accomodation= {{ "Postal_code", postacco }, { "Street_address", streetacco }, { "Areal", areal},  { "Price", price }, { "Rooms", rooms }, { "Currency", currency },
						 { "AgentID", agentid }, { "OfficeID", officeid }, { "Created", created },{ "Accomodation_Type", accomodtype },{ "Construction_year", consyear },{ "Last_updated", lastupdated },{ "Town", townacco },
						 { "Apartment", apartment }};
				Object[][] Owns= {{ "Own Street", ownstreet }, { "Status", statuscahnge }, { "Last_created_date", lastupdatedowns},  { "Owned", owned }};
				
				Object[][] Bankcrm= {{"BankCrmId", bankcrmid }, { "Bank AgentID", agentidbank }, { "Last_created_date", createdbank}};	
				
				Object[][] Interests= {{ "Created_date", createInt }, { "Status", statuscahngedInter }, { "Rating", rating},  { "Note", noteint }};
				int rowNum = 0;
				for (Object[] customers : dnbCustomers) {
					Row row = sheet.createRow(rowNum++);
					int column = 0;
					for (Object value : customers) {
						Cell cell = row.createCell(column++);
						if (value instanceof String) {
							cell.setCellValue((String) value);
						} else if (value instanceof Integer) {
							cell.setCellValue((Integer) value);
						}
					}
				}
				int rowNumAcc = 0;
				for (Object[] customers : Accomodation) {
					Row row = sheet1.createRow(rowNumAcc++);
					int column = 0;
					for (Object value : customers) {
						Cell cell = row.createCell(column++);
						if (value instanceof String) {
							cell.setCellValue((String) value);
						} else if (value instanceof Integer) {
							cell.setCellValue((Integer) value);
						}
					}
				}
				int rowNumOwns = 0;
				for (Object[] customers : Owns) {
					Row row = sheet2.createRow(rowNumOwns++);
					int column = 0;
					for (Object value : customers) {
						Cell cell = row.createCell(column++);
						if (value instanceof String) {
							cell.setCellValue((String) value);
						} else if (value instanceof Integer) {
							cell.setCellValue((Integer) value);
						}
					}
				}
				int rowNumBanks = 0;
				for (Object[] customers : Bankcrm) {
					Row row = sheet3.createRow(rowNumBanks++);
					int column = 0;
					for (Object value : customers) {
						Cell cell = row.createCell(column++);
						if (value instanceof String) {
							cell.setCellValue((String) value);
						} else if (value instanceof Integer) {
							cell.setCellValue((Integer) value);
						}
					}
				}
				int rowNumInter = 0;
				for (Object[] customers : Interests) {
					Row row = sheet4.createRow(rowNumInter++);
					int column = 0;
					for (Object value : customers) {
						Cell cell = row.createCell(column++);
						if (value instanceof String) {
							cell.setCellValue((String) value);
						} else if (value instanceof Integer) {
							cell.setCellValue((Integer) value);
						}
					}
				}
				workbook.write(fileOutput);
				response.setHeader("Content-Type", "application/vnd.ms-excel");
		           response.setHeader("Content-Transfer-Encoding", "binary");
		           response.setHeader("Content-Length", String.valueOf(file.length()));
		           response.addHeader("Content-Disposition", String.format("attachment; filename=%s", file.getName()));
		           
		           response.setContentType( "application/octet-stream" );
				System.out.println("Customers data exported");
				JFileChooser j = new JFileChooser(); 
				j.showSaveDialog(null);
				//workbook.close();
			}
			}
catch (IOException e) {
				e.printStackTrace();
			}
			return m1;

}
}
	
	/*@RequestMapping(value = "/cusDownLoadExcel/{temp}", method = RequestMethod.GET)
	@Produces("application/vnd.ms-excel")
	public Response getCustomerDetailsDownloadExcel(@PathVariable(value = "temp") String model,HttpServletResponse response, @RequestParam(defaultValue = DEFAULT_FILE_NAME) String fileName) throws IOException {
		
		final String FILE_PATH = "c:\\excel-file.xls";
		
		Model m;
		List<Person> custDet= null;
		 String fullName= model;
		    String last=fullName.split(" ")[fullName.split(" ").length-1];
		    String first = fullName.substring(0, fullName.length() - last.length());
		System.out.println("++++++++"+model);
		//System.out.println("++++++++"+model);
		 //List<Person> usersGateways = customerDetailsImpl.getCustomerDetails();
		ModelAndView m1 = new ModelAndView();
				try {
					custDet = customerDetailsImpl.exportToExcel(first,last);
					if (custDet != null) {
						//Person details
						String firstName= custDet.iterator().next().getFirstname();
						String lastName=custDet.iterator().next().getLastname();
						String mobile=custDet.iterator().next().getPhone_mobile();
						String phonehome=custDet.iterator().next().getPhone_home();
						String email= custDet.iterator().next().getEmail();
						String streetaddress= custDet.iterator().next().getStreetaddress();
						String postcode= custDet.iterator().next().getPostalcode();
						String economical= custDet.iterator().next().getEconomicaladvice();
						String town= custDet.iterator().next().getTown();
						String birthday= custDet.iterator().next().getBirthday();
						String note=custDet.iterator().next().getNote();
					    String emprof= custDet.iterator().next().getEmprofid();
						String ownership= custDet.iterator().next().getHasownership();
						String latestbiding= custDet.iterator().next().getLatestbidding();
						String buyer= custDet.iterator().next().getIsbuyer();
						
						//Accomodation details
						String postacco=custDet.iterator().next().getOwns().iterator().next().getAccomodation().getPostalcode();
						String streetacco=custDet.iterator().next().getOwns().iterator().next().getAccomodation().getStreetaddress();
						String areal=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getAreal();
						String price=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getPrice();
						String rooms=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getRooms();
						String currency=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getCurrency();
						String agentid=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getAgentid();
						String officeid=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getOfficeid();
						String created=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getCreated();
						String accomodtype=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getAccomodationtype();
						String consyear=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getConstructionyear();
						String lastupdated=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getLastupdated();
						String townacco=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getTown();
				        String apartment=custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getApartmentnumber();
						
				        //Owns deatisl
				        String ownstreet=custDet.iterator().next().getOwns().iterator().next().getSource();
						String statuscahnge= custDet.iterator().next().getOwns().iterator().next().getStatuschanged();
						String lastupdatedowns= custDet.iterator().next().getOwns().iterator().next().getLastupdated();
						String owned=custDet.iterator().next().getOwns().iterator().next().getOwned();
						
						//Bankcrm
						Integer id=custDet.iterator().next().getBankCrmLead().iterator().next().getId();
						String bankcrmid = Integer.toString(id);
						//model.addAttribute("personid", cus.iterator().next().getBankCrmLead().iterator().next().getPerson());
						String agentidbank=custDet.iterator().next().getBankCrmLead().iterator().next().getAgentid();
						String createdbank=custDet.iterator().next().getBankCrmLead().iterator().next().getCreated();
						
						
						//Interests
					//	model.addAttribute("idint", cus.iterator().next().getInterests().iterator().next().getAccomodation());
					//	model.addAttribute("peronint", cus.iterator().next().getInterests().iterator().next().);
						String createInt= custDet.iterator().next().getInterests().iterator().next().getCreated();
						String statuscahngedInter= custDet.iterator().next().getInterests().iterator().next().getStatuschanged();
						String rating= custDet.iterator().next().getInterests().iterator().next().getRating();
					String noteint= custDet.iterator().next().getInterests().iterator().next().getNote();
					
					String home = System.getProperty("user.home");
					File file = new File(home+"/Downloads/"+firstName+" "+lastName+".xlsx");
					
					FileDialog fc; 
					 fc = new FileDialog(new Frame(),"Open file", FileDialog.LOAD);
					  fc.setDirectory(".");
				        fc.setVisible(true);
				        String path=fc.getDirectory (  )  + fc.getFile (  ) ; 
				        System.out.println(path);
					JFileChooser customer = new JFileChooser();
					customer.setCurrentDirectory(new java.io.File("."));
					customer.setDialogTitle("CustomerTitle");
					customer.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
					customer.setAcceptAllFileFilterUsed(false);
					
					if(customer.showOpenDialog(null)==JFileChooser.APPROVE_OPTION)
					{
						   System.out.println("getCurrentDirectory(): " + customer.getCurrentDirectory());
						      System.out.println("getSelectedFile() : " + customer.getSelectedFile());
						    } else {
						      System.out.println("No Selection ");
						    }
					//String excelRootpath = "C:\\dnbexcel\\dnb.xlsx";
					FileOutputStream fileOutput = new FileOutputStream(file);
					// create xlsx workbook
					XSSFWorkbook workbook = new XSSFWorkbook();
					// create new worksheet
					XSSFSheet sheet = workbook.createSheet("Customer Details");
					XSSFSheet sheet1 = workbook.createSheet("Accomodation");
					XSSFSheet sheet2 = workbook.createSheet("Owns");
					XSSFSheet sheet3 = workbook.createSheet("Bank CRMLead");
					XSSFSheet sheet4 = workbook.createSheet("Interests");
					
					Object[][] dnbCustomers = { { "FirstName", firstName }, { "LastName", lastName }, { "Mobile", mobile},  { "Home_Phone", phonehome }, { "Email", email }, { "Street_Address", streetaddress },
							 { "Postal_code", postcode }, { "Economical", economical }, { "Town", town },{ "Birthday", birthday },{ "Note", note },{ "Town", town },{ "EmpProf", emprof },
							 { "Ownership", ownership },{ "latest_Biding", latestbiding },{ "Buyer", buyer }};
					
					Object[][] Accomodation= {{ "Postal_code", postacco }, { "Street_address", streetacco }, { "Areal", areal},  { "Price", price }, { "Rooms", rooms }, { "Currency", currency },
							 { "AgentID", agentid }, { "OfficeID", officeid }, { "Created", created },{ "Accomodation_Type", accomodtype },{ "Construction_year", consyear },{ "Last_updated", lastupdated },{ "Town", townacco },
							 { "Apartment", apartment }};
					Object[][] Owns= {{ "Own Street", ownstreet }, { "Status", statuscahnge }, { "Last_created_date", lastupdatedowns},  { "Owned", owned }};
					
					Object[][] Bankcrm= {{"BankCrmId", bankcrmid }, { "Bank AgentID", agentidbank }, { "Last_created_date", createdbank}};	
					
					Object[][] Interests= {{ "Created_date", createInt }, { "Status", statuscahngedInter }, { "Rating", rating},  { "Note", noteint }};
					int rowNum = 0;
					for (Object[] customers : dnbCustomers) {
						Row row = sheet.createRow(rowNum++);
						int column = 0;
						for (Object value : customers) {
							Cell cell = row.createCell(column++);
							if (value instanceof String) {
								cell.setCellValue((String) value);
							} else if (value instanceof Integer) {
								cell.setCellValue((Integer) value);
							}
						}
					}
					int rowNumAcc = 0;
					for (Object[] customers : Accomodation) {
						Row row = sheet1.createRow(rowNumAcc++);
						int column = 0;
						for (Object value : customers) {
							Cell cell = row.createCell(column++);
							if (value instanceof String) {
								cell.setCellValue((String) value);
							} else if (value instanceof Integer) {
								cell.setCellValue((Integer) value);
							}
						}
					}
					int rowNumOwns = 0;
					for (Object[] customers : Owns) {
						Row row = sheet2.createRow(rowNumOwns++);
						int column = 0;
						for (Object value : customers) {
							Cell cell = row.createCell(column++);
							if (value instanceof String) {
								cell.setCellValue((String) value);
							} else if (value instanceof Integer) {
								cell.setCellValue((Integer) value);
							}
						}
					}
					int rowNumBanks = 0;
					for (Object[] customers : Bankcrm) {
						Row row = sheet3.createRow(rowNumBanks++);
						int column = 0;
						for (Object value : customers) {
							Cell cell = row.createCell(column++);
							if (value instanceof String) {
								cell.setCellValue((String) value);
							} else if (value instanceof Integer) {
								cell.setCellValue((Integer) value);
							}
						}
					}
					int rowNumInter = 0;
					for (Object[] customers : Interests) {
						Row row = sheet4.createRow(rowNumInter++);
						int column = 0;
						for (Object value : customers) {
							Cell cell = row.createCell(column++);
							if (value instanceof String) {
								cell.setCellValue((String) value);
							} else if (value instanceof Integer) {
								cell.setCellValue((Integer) value);
							}
						}
					}
					workbook.write(fileOutput);
					
					response.setHeader("Content-Type", "application/vnd.ms-excel");
			           response.setHeader("Content-Transfer-Encoding", "binary");
			           response.setHeader("Content-Length", String.valueOf(file.length()));
			           response.addHeader("Content-Disposition", String.format("attachment; filename=%s", file.getName()));
			           
			           response.setContentType( "application/octet-stream" );
					System.out.println("Customers data exported");
					JFileChooser j = new JFileChooser(); 
					j.showSaveDialog(null);
					//workbook.close();
				}
				}
	catch (IOException e) {
					e.printStackTrace();
				}
				return m1;

	}
	}*/
	
	/*Model m;
	
	String fullName= model;
	
      String last=fullName.split(" ")[fullName.split(" ").length-1];
	    String first = fullName.substring(0, fullName.length() - last.length());
	List<Person> custDet= null;
	ModelAndView m1 = new ModelAndView();
	//String home = System.getProperty("Downloads");
	//File tempFile = new File(home+"/Downloads/" + fileName + ".xls"); 
	//JFileChooser
	   File tempFile = File.createTempFile(getClass().getName(), ".xls");
       try {
           FileOutputStream fos = new FileOutputStream(tempFile);
           try {
             custDet = customerDetailsImpl.exportToExcel(first, last);
       		if (custDet != null) {
       			// Person details
       			String firstName = custDet.iterator().next().getFirstname();
       			String lastName = custDet.iterator().next().getLastname();
       			String mobile = custDet.iterator().next().getPhone_mobile();
       			String phonehome = custDet.iterator().next().getPhone_home();
       			String email = custDet.iterator().next().getEmail();
       			String streetaddress = custDet.iterator().next().getStreetaddress();
       			String postcode = custDet.iterator().next().getPostalcode();
       			String economical = custDet.iterator().next().getEconomicaladvice();
       			String town = custDet.iterator().next().getTown();
       			String birthday = custDet.iterator().next().getBirthday();
       			String note = custDet.iterator().next().getNote();
       			String emprof = custDet.iterator().next().getEmprofid();
       			String ownership = custDet.iterator().next().getHasownership();
       			String latestbiding = custDet.iterator().next().getLatestbidding();
       			String buyer = custDet.iterator().next().getIsbuyer();

       			// Accomodation details
       			String postacco = custDet.iterator().next().getOwns().iterator().next().getAccomodation().getPostalcode();
       			String streetacco = custDet.iterator().next().getOwns().iterator().next().getAccomodation()
       					.getStreetaddress();
       			String areal = custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getAreal();
       			String price = custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getPrice();
       			String rooms = custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getRooms();
       			String currency = custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getCurrency();
       			String agentid = custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getAgentid();
       			String officeid = custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getOfficeid();
       			String created = custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getCreated();
       			String accomodtype = custDet.iterator().next().getOwns().listIterator().next().getAccomodation()
       					.getAccomodationtype();
       			String consyear = custDet.iterator().next().getOwns().listIterator().next().getAccomodation()
       					.getConstructionyear();
       			String lastupdated = custDet.iterator().next().getOwns().listIterator().next().getAccomodation()
       					.getLastupdated();
       			String townacco = custDet.iterator().next().getOwns().listIterator().next().getAccomodation().getTown();
       			String apartment = custDet.iterator().next().getOwns().listIterator().next().getAccomodation()
       					.getApartmentnumber();

       			// Owns deatisl
       			String ownstreet = custDet.iterator().next().getOwns().iterator().next().getSource();
       			String statuscahnge = custDet.iterator().next().getOwns().iterator().next().getStatuschanged();
       			String lastupdatedowns = custDet.iterator().next().getOwns().iterator().next().getLastupdated();
       			String owned = custDet.iterator().next().getOwns().iterator().next().getOwned();

       			// Bankcrm
       			Integer id = custDet.iterator().next().getBankCrmLead().iterator().next().getId();
       			String bankcrmid = Integer.toString(id);
       			// model.addAttribute("personid",
       			// cus.iterator().next().getBankCrmLead().iterator().next().getPerson());
       			String agentidbank = custDet.iterator().next().getBankCrmLead().iterator().next().getAgentid();
       			String createdbank = custDet.iterator().next().getBankCrmLead().iterator().next().getCreated();

       			// Interests
       			// model.addAttribute("idint",
       			// cus.iterator().next().getInterests().iterator().next().getAccomodation());
       			// model.addAttribute("peronint",
       			// cus.iterator().next().getInterests().iterator().next().);
       			String createInt = custDet.iterator().next().getInterests().iterator().next().getCreated();
       			String statuscahngedInter = custDet.iterator().next().getInterests().iterator().next().getStatuschanged();
       			String rating = custDet.iterator().next().getInterests().iterator().next().getRating();
       			String noteint = custDet.iterator().next().getInterests().iterator().next().getNote();

       			/*String excelRootpath = "C:\\dnbexcel\\dnb.xlsx";
       			FileOutputStream fileOutput = new FileOutputStream(new File(excelRootpath));*/
       			//File tempFile = File.createTempFile(getClass().getName(), ".xls");
/*
       			// create xlsx workbook
       			XSSFWorkbook workbook = new XSSFWorkbook();
       			// create new worksheet
       			XSSFSheet sheet = workbook.createSheet("Customer Details");
       			XSSFSheet sheet1 = workbook.createSheet("Accomodation");
       			XSSFSheet sheet2 = workbook.createSheet("Owns");
       			XSSFSheet sheet3 = workbook.createSheet("Bank CRMLead");
       			XSSFSheet sheet4 = workbook.createSheet("Interests");

       			Object[][] dnbCustomers = { { "FirstName", firstName }, { "LastName", lastName }, { "Mobile", mobile },
       					{ "Home_Phone", phonehome }, { "Email", email }, { "Street_Address", streetaddress },
       					{ "Postal_code", postcode }, { "Economical", economical }, { "Town", town },
       					{ "Birthday", birthday }, { "Note", note }, { "Town", town }, { "EmpProf", emprof },
       					{ "Ownership", ownership }, { "latest_Biding", latestbiding }, { "Buyer", buyer } };

       			Object[][] Accomodation = { { "Postal_code", postacco }, { "Street_address", streetacco },
       					{ "Areal", areal }, { "Price", price }, { "Rooms", rooms }, { "Currency", currency },
       					{ "AgentID", agentid }, { "OfficeID", officeid }, { "Created", created },
       					{ "Accomodation_Type", accomodtype }, { "Construction_year", consyear },
       					{ "Last_updated", lastupdated }, { "Town", townacco }, { "Apartment", apartment } };
       			Object[][] Owns = { { "Own Street", ownstreet }, { "Status", statuscahnge },
       					{ "Last_created_date", lastupdatedowns }, { "Owned", owned } };

       			Object[][] Bankcrm = { { "BankCrmId", bankcrmid }, { "Bank AgentID", agentidbank },
       					{ "Last_created_date", createdbank } };

       			Object[][] Interests = { { "Created_date", createInt }, { "Status", statuscahngedInter },
       					{ "Rating", rating }, { "Note", noteint } };
       			int rowNum = 0;
       			for (Object[] customers : dnbCustomers) {
       				Row row = sheet.createRow(rowNum++);
       				int column = 0;
       				for (Object value : customers) {
       					Cell cell = row.createCell(column++);
       					if (value instanceof String) {
       						cell.setCellValue((String) value);
       					} else if (value instanceof Integer) {
       						cell.setCellValue((Integer) value);
       					}
       				}
       			}
       			int rowNumAcc = 0;
       			for (Object[] customers : Accomodation) {
       				Row row = sheet1.createRow(rowNumAcc++);
       				int column = 0;
       				for (Object value : customers) {
       					Cell cell = row.createCell(column++);
       					if (value instanceof String) {
       						cell.setCellValue((String) value);
       					} else if (value instanceof Integer) {
       						cell.setCellValue((Integer) value);
       					}
       				}
       			}
       			int rowNumOwns = 0;
       			for (Object[] customers : Owns) {
       				Row row = sheet2.createRow(rowNumOwns++);
       				int column = 0;
       				for (Object value : customers) {
       					Cell cell = row.createCell(column++);
       					if (value instanceof String) {
       						cell.setCellValue((String) value);
       					} else if (value instanceof Integer) {
       						cell.setCellValue((Integer) value);
       					}
       				}
       			}
       			int rowNumBanks = 0;
       			for (Object[] customers : Bankcrm) {
       				Row row = sheet3.createRow(rowNumBanks++);
       				int column = 0;
       				for (Object value : customers) {
       					Cell cell = row.createCell(column++);
       					if (value instanceof String) {
       						cell.setCellValue((String) value);
       					} else if (value instanceof Integer) {
       						cell.setCellValue((Integer) value);
       					}
       				}
       			}
       			int rowNumInter = 0;
       			for (Object[] customers : Interests) {
       				Row row = sheet4.createRow(rowNumInter++);
       				int column = 0;
       				for (Object value : customers) {
       					Cell cell = row.createCell(column++);
       					if (value instanceof String) {
       						cell.setCellValue((String) value);
       					} else if (value instanceof Integer) {
       						cell.setCellValue((Integer) value);
       					}
       				}
       			}
       			workbook.write(fos);
       		}
       		
           }
           
       				
            finally {
               fos.close();
           }

           response.setHeader("Content-Type", "application/vnd.ms-excel");
           response.setHeader("Content-Transfer-Encoding", "binary");
           response.setHeader("Content-Length", String.valueOf(tempFile.length()));
           response.addHeader("Content-Disposition", String.format("attachment; filename=%s", tempFile.getName()));

           OutputStream outputStream = response.getOutputStream();
           FileInputStream fis = new FileInputStream(tempFile);
           try {
               int n = 0;
               byte[] buffer = new byte[1024];
               while ((n = fis.read(buffer)) != -1) {
                   outputStream.write(buffer, 0, n);
               }
               outputStream.flush();
           } finally {
               fis.close();
           }
       } finally {
           tempFile.delete();
       }
       return m1;
   }
}






/*
 * @ResponseBody
 * 
 * @RequestMapping(value = "/dnb/{searchKey}", method = RequestMethod.GET)
 * 
 * public ModelAndView getCustomerDetail(@PathVariable(value = "searchKey")
 * String searchKey, Model model) throws Exception { List<CustomerDetails> cusPo
 * = new ArrayList<CustomerDetails>(); ModelAndView m1 = new ModelAndView(); try
 * { cusPo = customerDetailsImpl.getCustomerDetailsKeySearch(searchKey);
 * model.addAttribute("mode", cusPo); m1.setViewName("search");
 * m1.addObject("model", model); } catch (Exception e) { System.out.println(e);
 * } return m1; }
 * 
 * @RequestMapping(value = "/customerAddDetails", method = RequestMethod.GET)
 * public @ResponseBody String getCustomerAddDetails(@FormParam("custid")
 * Integer custid,
 * 
 * @FormParam("name") String name, @FormParam("phoneNo") String phoneNo,
 * 
 * @FormParam("address") String address) {
 * System.out.println("inside customer details" + custid);
 * System.out.println("inside customer details" + name);
 * System.out.println("inside customer details" + phoneNo);
 * System.out.println("inside customer details" + address); CustomerDetails
 * customerDetailsModel = new CustomerDetails();
 * customerDetailsModel.setId(custid); customerDetailsModel.setName(name);
 * customerDetailsModel.setPhone(phoneNo);
 * customerDetailsModel.setAddress(address); String message =
 * customerDetailsImpl.addCustomerDetails(customerDetailsModel); return message;
 * }
 * 
 * @RequestMapping(value = "/customerDeleteDetails", method = RequestMethod.GET)
 * public @ResponseBody String getCustomerAddDetails(@FormParam("custid")
 * Integer custid) { System.out.println("inside customer details" + custid);
 * String message = customerDetailsImpl.deleteCustomerDetails(custid); return
 * message; }
 */
